<?php 
$lang = ICL_LANGUAGE_CODE;
$perfix = $lang === 'ar' ? '_ar' : '';
		$purchase_form_img       = get_option('purchase_form_img'.$perfix);
        $purchase_left_title     = get_option('purchase_left_title'.$perfix);
        $purchase_first_img      = get_option('purchase_first_img'.$perfix);
        $purchase_second_img     = get_option('purchase_second_img'.$perfix);
        $purchase_third_img      = get_option('purchase_third_img'.$perfix);
        $purchase_form_title     = get_option('purchase_form_title'.$perfix);