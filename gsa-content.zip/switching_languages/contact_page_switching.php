<?php 
$lang = ICL_LANGUAGE_CODE;
$perfix = $lang === 'ar' ? '_ar' : '';
		$gsa_main_img                   			= get_option('gsa_main_img'.$perfix);
		$contact_page_title                   		= get_option('contact_page_title'.$perfix);
		$contact_page_sub_title                  	= get_option('contact_page_sub_title'.$perfix);
		$contact_page_sub_title                   	= get_option('contact_page_sub_title'.$perfix);
		$contact_page_content                   	= get_option('contact_page_content'.$perfix);
		$contact_page_btn_url                   	= get_option('contact_page_btn_url'.$perfix);
		$contact_page_btn_text                   	= get_option('contact_page_btn_text'.$perfix);
		$gsa_background_pattern_img                 = get_option('gsa_background_pattern_img'.$perfix);
		$contact_first_section_title                = get_option('contact_first_section_title'.$perfix);
		$contacts_shortcode                   		= get_option('contacts_shortcode'.$perfix);
		$gsa_phone                   				= get_option('gsa_phone'.$perfix);
		$gsa_phone                   				= get_option('gsa_phone'.$perfix);
		$gsa_email                   				= get_option('gsa_email'.$perfix);
		$gsa_email                   				= get_option('gsa_email'.$perfix);
		$gsa_location                   			= get_option('gsa_location'.$perfix);