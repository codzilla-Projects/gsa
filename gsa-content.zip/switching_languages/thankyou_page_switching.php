<?php 
$lang = ICL_LANGUAGE_CODE;
$perfix = $lang === 'ar' ? '_ar' : '';
		$thankyou_img              =  get_option('thankyou_img'.$perfix);
        $thankyou_Message          =  get_option('thankyou_Message'.$perfix);