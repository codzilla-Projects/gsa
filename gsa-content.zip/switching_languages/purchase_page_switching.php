<?php 
$lang = ICL_LANGUAGE_CODE;
$perfix = $lang === 'ar' ? '_ar' : '';
		$partner_form_img      = get_option('partner_form_img'.$perfix);