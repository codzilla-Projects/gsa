<?php
/**
** Template Name: Partners Template
**/
	require_once( gsa_ROOT  . '/switching_languages/partners_page_switching.php');
	get_header(); 
?>
<section class="purchase-page" style="background-image:url('<?= $purchase_form_img; ?>')">
	<div class="container-fluid p-0">
		<div class="row">
			<div class="col-lg-4 col-md-12 col-sm-12">
				<div class="purchase-left">
					<div class="sec-title">
						<h2>
							<?= $purchase_left_title; ?>						
						</h2>
					</div>
					<div class="purchase-left-img">
						<img src="<?= $purchase_first_img; ?>">
					</div>
					<div class="purchase-left-img">
						<img src="<?= $purchase_second_img; ?>">
					</div>

					<div class="purchase-left-img">
						<img src="<?= $purchase_third_img; ?>">
					</div>
				</div>
			</div>
			<div class="col-lg-8 col-md-12 col-sm-12">
				<div class="purchase-form">
					<div class="title">
						<h2>
							<?= $purchase_form_title; ?>
						</h2>
					</div>
				
					<div class="form-box">
						<div class="default-form">
							<form method="post" action="" id="contact-form">
								 <?php if(isset($_POST['registerPurchase']) && $_POST['registerPurchase'] === "Register"):
						            $response = gsa_register_new_purchase($_POST);
						          ?>
						            <?php endif ?>
								<div class="row clearfix">
									<div class="form-group col-lg-6 col-md-12 col-sm-12">
										<label>Name<span>*</span></label>
										<div class="field-inner">
											<input type="text" name="fullname" value=""
												required="">
										</div>
									</div>
									<div class="form-group col-lg-6 col-md-12 col-sm-12">
										<label>Email(business email only)<span>*</span></label>
										<div class="field-inner">
											<input type="email" name="email" value=""
												required="">
										</div>
									</div>

									<div class="form-group col-lg-6 col-md-12 col-sm-12">
										<label>Phone Number<span>*</span></label>
										<div class="field-inner">
											<input type="tel" name="phone" value=""
												required="">
										</div>
									</div>

									<div class="form-group col-lg-6 col-md-12 col-sm-12">
										<label>Governorate<span>*</span></label>

										<div class="field-inner multiSelect_field">
					                        <select  name="governorate" class="js-example-basic-multiple">
					                         	<option value = ''>Choose Governorate</option>
												<option>Riyadh</option>
												<option>Diriyah</option>
												<option>Al-Kharj</option>
												<option>Dawadmi</option>
												<option>Al Majma'ah</option>
												<option>Al-Quway'iyah</option>
												<option>Wadi ad-Dawasir</option>
												<option>Al Aflaj</option>
												<option>Al Zulfi</option>
												<option>Shuqrah</option>
												<option>Hotat Bani Tamim</option>
												<option>Afif</option>
												<option>As Sulayyil</option>
												<option>Dhurma</option>
												<option>Al-Muzahmiyya</option>
												<option>Rumah</option>
												<option>Thadig</option>
												<option>Huraymila</option>
												<option>Al Hariq</option>
												<option>Al-Ghat</option>
												<option>Mecca</option>
												<option>Jeddah</option>
												<option>Ta'if</option>
												<option>Al Qunfudhah</option>
												<option>Al Lith</option>
												<option>Rabigh</option>
												<option>Al Jumum</option>
												<option>Khulays</option>
												<option>Al Kamil</option>
												<option>Al Khurmah</option>
												<option>Ranyah</option>
												<option>Turubah</option>
												<option>Medina</option>
												<option>Yanbu</option>
												<option>Al-`Ula</option>
												<option>Mahd adh Dhahab</option>
												<option>Badr</option>
												<option>Khaybar</option>
												<option>Al Hinakiyah</option>
												<option>Buraidah</option>
												<option>Unaizah</option>
												<option>Ar Rass</option>
												<option>Al Mithnab</option>
												<option>Al Bukayriyah</option>
												<option>Al Badayea</option>
												<option>Asyah</option>
												<option>Al Nabhaniyah</option>
												<option>Uyun AlJiwa</option>
												<option>Riyadh Al Khabra</option>
												<option>Al Shimasiyah</option>
												<option>Dammam</option>
												<option>Al Ahsa</option>
												<option>Hafar Al-Batin</option>
												<option>Jubail</option>
												<option>Qatif</option>
												<option>Khobar</option>
												<option>Khafji</option>
												<option>Ras Tanura</option>
												<option>Abqaiq</option>
												<option>Al Nairyah</option>
												<option>Qaryat al-Ulya</option>
												<option>Abha</option>
												<option>Khamis Mushait</option>
												<option>Bisha</option>
												<option>Al-Namas</option>
												<option>Muhayil</option>
												<option>Sarat Abidah</option>
												<option>Tathlith</option>
												<option>Rojal</option>
												<option>Ahad Rafidah</option>
												<option>Dhahran Al Janub</option>
												<option>Balqarn</option>
												<option>Al Majaridah</option>
												<option>Tabuk</option>
												<option>Al Wajh</option>
												<option>Duba</option>
												<option>Tayma</option>
												<option>Umluj</option>
												<option>Haql</option>
												<option>Ha'il</option>
												<option>Baqaa</option>
												<option>Al Khazaiah</option>
												<option>Al Shinan</option>
												<option>Arar</option>
												<option>Rafha</option>
												<option>Turaif</option>
												<option>Jizan</option>
												<option>Sabya</option>
												<option>Abu `Arish</option>
												<option>Samtah</option>
												<option>Al Harth</option>
												<option>Damad</option>
												<option>Al Reeth</option>
												<option>Baish</option>
												<option>Farasan</option>
												<option>Al Dayer</option>
												<option>Ahad al Masarihah</option>
												<option>Al Edabi</option>
												<option>Al Aridhah</option>
												<option>Al Darb</option>
												<option>Najran</option>
												<option>Sharurah</option>
												<option>Hubuna</option>
												<option>Badr Al Janub</option>
												<option>Yadamah</option>
												<option>Thar</option>
												<option>Khubash</option>
												<option>Al Kharkhir</option>
												<option>Al Bahah</option>
												<option>Baljurashi</option>
												<option>Al Mandaq</option>
												<option>Al Makhwah</option>
												<option>Al Aqiq</option>
												<option>Qilwah</option>
												<option>Al Qara</option>
												<option>Sakakah</option>
												<option>Qurayyat</option>
												<option>Dumat al-Jandal</option>
					                        </select>
					                    </div>
									</div>
									<div class="form-group col-lg-6 col-md-12 col-sm-12">
										<label>Organization<span>*</span></label>
										<div class="field-inner">
											<input type="text" name="organization" value=""
												required="">
										</div>
									</div>
									<div class="form-group col-lg-6 col-md-12 col-sm-12">
										<label>Job title<span>*</span></label>
										<div class="field-inner">
											<input type="text" name="job_title" value=""
												required="">
										</div>
									</div>
									<?php
					                    $programs = gsa_get_program(-1);
					                    if($programs->have_posts()) :
					                ?>
									<div class="form-group col-lg-6 col-md-12 col-sm-12">
										<label>Programs<span>*</span></label>
										<div class="field-inner multiSelect_field">
										 <select  name="programs[]" multiple class="js-example-basic-multiple" required="">
			                                 <?php while($programs->have_posts()) : $programs->the_post();
			                                  $programs_id= get_the_ID();
			                                 
			                                 ?>
			                                    <option value="<?php the_title()?>" ><?php the_title()?></option>
			                                <?php endwhile; wp_reset_query();?>
			                                </select>
										</div>

									</div>
									<?php endif;?>
									<div class="form-group col-lg-6 col-md-12 col-sm-12">
										<label>Industry<span>*</span></label>
										<div class="field-inner multiSelect_field">
										 <select  name="industry" class="js-example-basic-multiple" required="">
			                                <option value = ''>Choose industry      </option>
			                                <option>Human Resources and Recruitment</option>
                                            <option>Education</option>
                                            <option>Information and Communication</option>
                                            <option>Primary Industries (Agriculture, Forestry, Fishing, Mining, and Quarrying)</option>
                                            <option>Manufacturing</option>
                                            <option>Utilities and Environmental Services (Electricity, Gas, Water Supply, and Environmental Services)</option>
                                            <option>Construction</option>
                                            <option>Transportation and Storage</option>
                                            <option>Wholesale and Retail Trade</option>
                                            <option>Technology and Software Development</option>
                                            <option>Accommodation and Food Services</option>
                                            <option>Financial and Insurance Services</option>
                                            <option>Real Estate Activities</option>
                                            <option>Professional, Scientific, and Technical Services</option>
                                            <option>Administrative and Support Services</option>
                                            <option>Public Administration and Defense</option>
                                            <option>Human Health and Social Work Activities</option>
                                            <option>Arts, Entertainment, and Recreation</option>
                                            <option>Other Services (e.g., personal, community, and social services)</option>
			                                
			                                </select>
										</div>

									</div>

									<div class="form-group col-lg-12 col-md-12 col-sm-12">
										<div class="field-inner">
											<div class="news-letter">
												<div class="checkboxes">
												  <div class="checkboxes__row">
													<div class="checkboxes__item">
													  <label class="checkbox style-d">
														<input type="checkbox" value="Agree" checked="checked" name="send_news">
														<div class="checkbox__checkmark"></div>
														<div class="checkbox__body">Receive updates/subscribe to newsletter</div>
													  </label>
													</div>
												  </div>
												</div>
											</div>
										</div>
									</div>
									<div class="form-group col-lg-12 col-md-12 col-sm-12 d-flex justify-content-center">
										<button class="thm-btn second-thm-btn"  type="submit" name="registerPurchase" value="Register" onclick="redirect();">
											Submit
										</button>
									</div>
								</div>
								 <?php if($response['status'] == 1): ?>
					                <script type='text/javascript'>window.setTimeout(function(){window.location.href = '<?php bloginfo('url') ?>/thank-you'}, 800);</script>
					            <?php endif ?>
					           
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer()?>
