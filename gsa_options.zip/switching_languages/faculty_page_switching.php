<?php 
$lang = ICL_LANGUAGE_CODE;
$perfix = $lang === 'ar' ? '_ar' : '';
	$faculty_page_title                          =  get_option('faculty_page_title'.$perfix);
	$faculty_first_section_hidden                =  get_option('faculty_first_section_hidden'.$perfix);
	$home_fourth_number                          =  get_option('home_fourth_number'.$perfix);
	$home_fourth_title                           =  get_option('home_fourth_title'.$perfix);
	$faculty_second_section_hidden               =  get_option('faculty_second_section_hidden'.$perfix);
	$faculty_second_section_img                  =  get_option('faculty_second_section_img');
	$vision_title                                =  get_option('vision_title'.$perfix);
	$faculty_second_section_content              =  get_option('faculty_second_section_content'.$perfix);
	$faculty_third_section_hidden                =  get_option('faculty_third_section_hidden'.$perfix);
	$gsa_home_element_one_title                  =  get_option('gsa_home_element_one_title'.$perfix);
	$gsa_home_element_one_title                  =  get_option('gsa_home_element_one_title'.$perfix);
	$gsa_home_element_one_para                   =  get_option('gsa_home_element_one_para'.$perfix);
	$gsa_home_element_two_title                  =  get_option('gsa_home_element_two_title'.$perfix);
	$gsa_home_element_two_title                  =  get_option('gsa_home_element_two_title'.$perfix);
	$gsa_home_element_two_para                   =  get_option('gsa_home_element_two_para'.$perfix);
